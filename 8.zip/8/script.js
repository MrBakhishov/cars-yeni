// let cars = ['bmw', 'mersedes', 'opel', 'lada', 'niva','nissan'];

// cars.splice(4,1);

// console.log(cars);

// cars.unshift('lada');

// console.log(cars);

// cars.shift();

// console.log(cars);

// alert(cars.pop())

// console.log(cars);

// cars.push('lada');

// console.log(cars);

// let cars = ['bmw', 'mersedes', 'opel'];

// cars.push(['a','b', 'c']);

// console.log(cars);

// console.log(cars[3][1]);

// let todo = [];
// function Add() {
//   let inp = document.getElementById("inp");
//   let list = document.getElementById("list");
//   let error = document.getElementById("error");

//   if (inp.value == "") {
//     error.style.display = 'inline'
//    error.innerHTML = 'Olmaz';
//   } else {
//     error.style.display = 'none'
//     todo.push(inp.value);
//     inp.value = "";
//     ekran();
//   }
// }
// function Delete(index){
//     todo.splice(index,1);
//     ekran();
// }

// function ekran(){
//     let data = "";
//     todo.forEach(function (item, index) {
//       data += `<li class="list-group-item d-flex justify-content-between"> ${item} <button onclick="Delete(${index})" class="btn btn-danger btn-sm"> Delete </button>  </li>`;
//     });

//     list.innerHTML = data;
// }


//olke var qur


//let marka = [
//   'Bmw',
//   'Opel',
//  'Mersedes'
//];


//let model = [
//   ['x5','x6','x7','x8'],
//  ['astra', 'vectra', 'zafira'],
//  ['e class', 'c class', '190']
//]



///let markaS = document.getElementById("marka");
//let modelS = document.getElementById("model");

//let data = `<option value="" selected  disabled > Marka Secin </option>`
//for(let i =0; i<marka.length; i++){
//  data+= `<option value="${i}"> ${marka[i]} </option>`
//}
//markaS.innerHTML = data;



//function Sec(){
//   let val = markaS.value;
//  let data = `<option value="" selected  disabled > Model Secin </option>`
//  for(let i =0; i<model[val].length; i++){
//      data+= `<option value="${i}"> ${model[val][i]} </option>`
//  }

// modelS.innerHTML = data;

//}





let marka = [
    'Bmw',
    'Opel',
    'Mersedes'
];


let model = [
    ['x5', 'x6', 'x7', 'x8'],
    ['astra', 'vectra', 'zafira'],
    ['e class', 'c class', '190']
]

 //let img = [
 // ['img/bmw-x5.jpg',`img/bmw-x6.jpg`, `img/BMW-X7.jpg`]
 //  [`img/opelastra.jpg`]
  // [`img/E-Class.jpg`]
 //]


let markaS = document.getElementById("marka");
let modelS = document.getElementById("model");

let data = `<option value="" selected  disabled > Marka Secin </option>`
for (let i = 0; i < marka.length; i++) {
    data += `<option value="${i}"> ${marka[i]} </option>`
}
markaS.innerHTML = data;



function Sec() {
    let val = markaS.value;
    let data = `<option value="" selected  disabled > Model Secin </option>`
    for (let i = 0; i < model[val].length; i++) {
        data += `<option value="${i}"> ${model[val][i]} </option>`
    }

    modelS.innerHTML = data;

}

function img(){
   let markav = markaS.value;
   let modelv = modelS.value;

   document.getElementById('text').innerHTML = `siz ${marka[markav]} -nin ${model[markav][modelv]} secdiniz`
  document.getElementById('show').innerHTML = `<img src="img/bmw-x5.jpg " > <img src="img/bmw-x6.jpg"> <img src="img/BMW-X7.jpg"> <img src="img/opelastra.jpg"> <img src="img/E-Class.jpg">`
 // document.getElementById('show').innerHTML = `<img src="${img[markav][modelv]}">`
   let data = `<option value="" selected  disabled > Model Secin </option>`
    for(let i =0; i<model[val].length; i++){
       data+= `<option value="${i}"> ${model[val][i]} </option>`
    }

   modelS.innerHTML = data;


}